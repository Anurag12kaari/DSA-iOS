#include <iostream>
#include <string>

int main() {
    std::string str = "Hello, C++!";
    std::cout << "Length of string: " << str.length() << std::endl;
    std::cout << "Character at index 7: " << str[7] << std::endl;
    return 0;
}
