    Local variables are destroyed when the function returns.

    Returning their address leads to undefined behavior(dangling pointer)