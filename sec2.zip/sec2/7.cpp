/*Write a C++ program to dynamically allocate an integer using new, assign it a value,
print it, and then deallocate it using delete.
ptr is the house
*ptr is the person living there*/

#include <iostream>
using namespace std;

int main(){
    int* ptr = new int;

    *ptr = 24;
    cout << "the value of the integer is " << *ptr << endl;
    delete ptr;
    return 0;
}