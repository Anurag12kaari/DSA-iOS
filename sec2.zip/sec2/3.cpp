/*Write a C function that takes two integer pointers as arguments and swaps the integers
they point to.*/

#include <iostream>
using namespace std;


// a is a pointer that points to an integer ,  *a : temp takes the value stored in integer pointer a 
void swap(int* a, int* b){
    int temp = *a;
    *a = *b;
    *b = temp;
}

int main(){
    int a =10;
    int b = 20;
    cout << "Before: " << a << " " << b << endl;
    swap(&a,&b);
    cout << "after: " << a << " " << b << endl;
    return 0;
}

