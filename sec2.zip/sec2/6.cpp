/*Write a C program to demonstrate pointer arithmetic (incrementing a pointer,
decrementing a pointer, adding an integer to a pointer, subtracting pointers).*/

#include <iostream>
using namespace std;

int main() {
    int arr[] = {10, 20, 30, 40, 50};
    int* ptr = arr;  // Points to the first element

    cout << "Original pointer points to: " << *ptr << endl;

    // Incrementing the pointer
    ptr++;
    cout << "After incrementing, pointer points to: " << *ptr << endl;

    // Decrementing the pointer
    ptr--;
    cout << "After decrementing, pointer points to: " << *ptr << endl;

    // Adding an integer to the pointer
    ptr = ptr + 2;
    cout << "After adding 2, pointer points to: " << *ptr << endl;

    // Subtracting pointers
    int* ptr2 = &arr[4];  // Points to last element
    int diff = ptr2 - ptr;  // Difference in elements
    cout << "ptr2 - ptr = " << diff << " (elements apart)" << endl;

    return 0;
}



