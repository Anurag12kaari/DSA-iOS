/*Explain RAII (Resource Acquisition Is Initialization) in C++ with a simple conceptual
example (no need for complex classes yet).


RAII is a C++ programming concept where resource management (like memory, files, or locks) is tied to object lifetime.
When an object is created, it acquires the resource.
When the object is destroyed (goes out of scope), it releases the resource automatically.

Ensures resources are always cleaned up properly — even if an exception is thrown

*/

#include <iostream>
#include <fstream>
using namespace std;

int main() {
    {
        ofstream file("example.txt");  // Resource acquired here (file opened)
        if (file.is_open()) {
            file << "Hello, RAII!" << endl;
        }
        // No need to call file.close() manually!
        // When 'file' goes out of scope, its destructor is called,
        // and the file is automatically closed.
    }  // file is destroyed here, resource released

    cout << "File closed automatically using RAII." << endl;
    return 0;
}
