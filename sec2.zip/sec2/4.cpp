/*Write a Cpp program to dynamically allocate memory for an array of 5 integers using
malloc. Initialize these integers, print them, and then free the allocated memory.*/




#include <iostream>
#include <cstdlib>
using namespace std;

int main(){
//memory allocation
int* arr = (int*) malloc (5 * sizeof(int));

if (arr == NULL) {
    cout << "memory allocation failed" << endl;
    return 1;
}

//array initialization
for(int i=0; i<5; i++){
    arr[i] = (i+ 1) * 10;
}

//printing
cout << "array elements are " << endl;
for(int i=0; i<5; i++){
   cout <<  arr[i] << " ";
}


//free memory
free(arr);
return 0;
}