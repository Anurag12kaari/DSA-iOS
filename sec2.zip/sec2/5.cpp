/*What is the difference between malloc() and calloc() in C? When would you prefer one
over the other?

malloc - allocates a block of memory but wont initialize it
calloc - will allocate and initalize 
int *a = (int*) malloc(5 * sizeof(int));   // Garbage values in a[0] to a[4]
int *b = (int*) calloc(5, sizeof(int));    // All b[0] to b[4] are 0
*/
