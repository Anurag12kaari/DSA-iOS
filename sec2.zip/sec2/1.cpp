/*Write a C program to demonstrate the use of sizeof operator for different data types
and pointer variables.*/


#include <iostream>
using namespace std;

int main(){
    int a;
    float b;
    char c;
    double d;
    string e;
    short f;
    long g;
    bool h;

    int* p1;
    float* p2;
    char* p3;
    double* p4;
    string* p5;
    cout << "size of int is " << sizeof(int) << endl;
    cout << "size of float is " << sizeof(float) << endl;
    cout << "size of char is " << sizeof(char) << endl;
    cout << "size of double is " << sizeof(double) << endl;
    cout << "size of string is " << sizeof(string) << endl;
    cout << "size of long is " << sizeof(long) << endl;
    cout << "size of short is " << sizeof(short) << endl;
    cout << "size of bool is " << sizeof(bool) << endl;


    cout << "size of int* is " << sizeof(p1) << endl;
    cout << "size of float* is " << sizeof(p2) << endl;
    cout << "size of char* is " << sizeof(p3) << endl;
    cout << "size of double* is " << sizeof(p4) << endl;
    cout << "size of string* is " << sizeof(p5) << endl;

    return 0;
}