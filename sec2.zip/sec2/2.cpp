/*Explain the concept of a null pointer and a dangling pointer in C. Provide a small code
example for a dangling pointer scenario.

null pointer points to nothing and its used to indicate that it has not alloted a valid address space

int *ptr = NULL;
dangling pointer points to the address space which is freed or deleted*/

#include <stdio.h>
#include <stdlib.h>

int main() {
    int *ptr = (int*) malloc(sizeof(int));
    *ptr = 10;
    free(ptr); 
    //ptr= NULL;           //correct way
    printf("%d\n", *ptr); //  Dangling pointer - accessing freed memory invalid

     
    return 0;
}



